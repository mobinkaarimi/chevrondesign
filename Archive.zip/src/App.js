import React from 'react';
import ChevronList from "./components/chevronList";
const App = () => {
    return (
        <div>
            <h1>Payment Status</h1>
            <ChevronList />
        </div>
    );
};

export default App;